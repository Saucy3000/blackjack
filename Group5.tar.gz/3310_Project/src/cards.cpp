#include "cards.h"
#include<vector>
#include<iostream>
#include<string>

CARD::CARD() // Defualt Constructor
{
	
}

CARD::CARD(std::string v, std::string s, int r)
{
	value=v;
	suite=s;
	reference=r; 
}

int CARD::get_numeric_value()
{
	std::string test = value;
	if (test == "2")
		return 2;
	else if (test == "3")
		return 3;
	else if (test == "4")
		return 4;
	else if (test == "5")
		return 5;
	else if (test == "6")
		return 6;
	else if (test == "7")
		return 7;
	else if (test == "8")
		return 8;
	else if (test == "9")
		return 9;
	else if (test == "10")
		return 10;
	else if (test == "Jack")
		return 10;
	else if (test == "Queen")
		return 10;
	else if (test == "King")
		return 10;
	else if (test == "Ace")
		return 11;
	else 
		return 0;
}

std::string CARD::get_value()
{
	return value;
}

std::string CARD::get_suite()
{
	return suite;
}

int CARD::get_reference()
{
	return reference;
}

void CARD::set_value(std::string s)
{
  value = s;
}

void CARD::set_suite(std::string s)
{
  suite = s;
}

DECK::DECK()
{
		deck.push_back(CARD("2"    ,"Spades", 1 ));
		deck.push_back(CARD("3"    ,"Spades"  , 2 ));
		deck.push_back(CARD("4"    ,"Spades"  , 3));
		deck.push_back(CARD("5"    ,"Spades"  , 4));
		deck.push_back(CARD("6"    ,"Spades"  , 5));
		deck.push_back(CARD("7"    ,"Spades"  , 6));
		deck.push_back(CARD("8"    ,"Spades"  , 7));
		deck.push_back(CARD("9"    ,"Spades"  , 8));
		deck.push_back(CARD("10"   ,"Spades"  , 9));
		deck.push_back(CARD("Jack" ,"Spades"  , 10));
		deck.push_back(CARD("Queen","Spades"  , 11));
		deck.push_back(CARD("King" ,"Spades"  , 12));
		deck.push_back(CARD("Ace"  ,"Spades"  , 13));
		deck.push_back(CARD("2"    ,"Hearts"  , 14));
		deck.push_back(CARD("3"    ,"Hearts"  , 15));
		deck.push_back(CARD("4"    ,"Hearts"  , 16));
		deck.push_back(CARD("5"    ,"Hearts"  , 17));
		deck.push_back(CARD("6"    ,"Hearts"  , 18));
		deck.push_back(CARD("7"    ,"Hearts"  , 19));
		deck.push_back(CARD("8"    ,"Hearts"  , 20));
		deck.push_back(CARD("9"    ,"Hearts"  , 21));
		deck.push_back(CARD("10"   ,"Hearts"  , 22));
		deck.push_back(CARD("Jack" ,"Hearts"  , 23));
		deck.push_back(CARD("Queen","Hearts"  , 24));
		deck.push_back(CARD("King" ,"Hearts"  , 25));
		deck.push_back(CARD("Ace"  ,"Hearts"  , 26));
		deck.push_back(CARD("2"    ,"Clubs"   , 27));
		deck.push_back(CARD("3"    ,"Clubs"   , 28));
		deck.push_back(CARD("4"    ,"Clubs"   , 29));
		deck.push_back(CARD("5"    ,"Clubs"   , 30));
		deck.push_back(CARD("6"    ,"Clubs"   , 31));
		deck.push_back(CARD("7"    ,"Clubs"   , 32));
		deck.push_back(CARD("8"    ,"Clubs"   , 33));
		deck.push_back(CARD("9"    ,"Clubs"   , 34));
		deck.push_back(CARD("10"   ,"Clubs"   , 35));
		deck.push_back(CARD("Jack" ,"Clubs"   , 36));
		deck.push_back(CARD("Queen","Clubs"   , 37));
		deck.push_back(CARD("King" ,"Clubs"   , 38));
		deck.push_back(CARD("Ace"  ,"Clubs"   , 39));
		deck.push_back(CARD("2"    ,"Diamonds", 40));
		deck.push_back(CARD("3"    ,"Diamonds", 41));
		deck.push_back(CARD("4"    ,"Diamonds", 42));
		deck.push_back(CARD("5"    ,"Diamonds", 43));
		deck.push_back(CARD("6"    ,"Diamonds", 44));
		deck.push_back(CARD("7"    ,"Diamonds", 45));
		deck.push_back(CARD("8"    ,"Diamonds", 46));
		deck.push_back(CARD("9"    ,"Diamonds", 47));
		deck.push_back(CARD("10"   ,"Diamonds", 48));
		deck.push_back(CARD("Jack" ,"Diamonds", 49));
		deck.push_back(CARD("Queen","Diamonds", 50));
		deck.push_back(CARD("King" ,"Diamonds", 51));
		deck.push_back(CARD("Ace"  ,"Diamonds", 52));
   
}

    CARD DECK::ref_check(int ref)
    {
       for (int i=0; i< (int)deck.size(); i++)
       {
       	  if(ref == deck[i].get_reference())
       	  {
       	  	 return deck[i];
       	  }
       }
        
       CARD nill;
       return nill;
    }
