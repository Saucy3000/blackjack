//
// blackjack_game.cpp
// ~~~~~~~~~~~~~~~
//

#include <algorithm>
#include <cstdlib>
#include <deque>
#include <iostream>
#include <list>
#include <vector>
#include <unistd.h>
#include <memory>
#include <set>
#include <utility>
#include "asio.hpp"
#include "chat_message.hpp"
#include "cards.cpp"
#include  <ctime>

using asio::ip::tcp;

//----------------------------------------------------------------------

typedef std::deque<chat_message> chat_message_queue;

static std::vector<CARD> shuffle ()
{
    srand(unsigned(time(0)));
    
	int i=0;
	std::vector<CARD> ndeck;
	for (;i<6;i++)
	{
		ndeck.push_back(CARD("2"    ,"Spades"  , 1 ));
		ndeck.push_back(CARD("3"    ,"Spades"  , 2 ));
		ndeck.push_back(CARD("4"    ,"Spades"  , 3));
		ndeck.push_back(CARD("5"    ,"Spades"  , 4));
		ndeck.push_back(CARD("6"    ,"Spades"  , 5));
		ndeck.push_back(CARD("7"    ,"Spades"  , 6));
		ndeck.push_back(CARD("8"    ,"Spades"  , 7));
		ndeck.push_back(CARD("9"    ,"Spades"  , 8));
		ndeck.push_back(CARD("10"   ,"Spades"  , 9));
		ndeck.push_back(CARD("Jack" ,"Spades"  , 10));
		ndeck.push_back(CARD("Queen","Spades"  , 11));
		ndeck.push_back(CARD("King" ,"Spades"  , 12));
		ndeck.push_back(CARD("Ace"  ,"Spades"  , 13));
		ndeck.push_back(CARD("2"    ,"Hearts"  , 14));
		ndeck.push_back(CARD("3"    ,"Hearts"  , 15));
		ndeck.push_back(CARD("4"    ,"Hearts"  , 16));
		ndeck.push_back(CARD("5"    ,"Hearts"  , 17));
		ndeck.push_back(CARD("6"    ,"Hearts"  , 18));
		ndeck.push_back(CARD("7"    ,"Hearts"  , 19));
		ndeck.push_back(CARD("8"    ,"Hearts"  , 20));
		ndeck.push_back(CARD("9"    ,"Hearts"  , 21));
		ndeck.push_back(CARD("10"   ,"Hearts"  , 22));
		ndeck.push_back(CARD("Jack" ,"Hearts"  , 23));
		ndeck.push_back(CARD("Queen","Hearts"  , 24));
		ndeck.push_back(CARD("King" ,"Hearts"  , 25));
		ndeck.push_back(CARD("Ace"  ,"Hearts"  , 26));
		ndeck.push_back(CARD("2"    ,"Clubs"   , 27));
		ndeck.push_back(CARD("3"    ,"Clubs"   , 28));
		ndeck.push_back(CARD("4"    ,"Clubs"   , 29));
		ndeck.push_back(CARD("5"    ,"Clubs"   , 30));
		ndeck.push_back(CARD("6"    ,"Clubs"   , 31));
		ndeck.push_back(CARD("7"    ,"Clubs"   , 32));
		ndeck.push_back(CARD("8"    ,"Clubs"   , 33));
		ndeck.push_back(CARD("9"    ,"Clubs"   , 34));
		ndeck.push_back(CARD("10"   ,"Clubs"   , 35));
		ndeck.push_back(CARD("Jack" ,"Clubs"   , 36));
		ndeck.push_back(CARD("Queen","Clubs"   , 37));
		ndeck.push_back(CARD("King" ,"Clubs"   , 38));
		ndeck.push_back(CARD("Ace"  ,"Clubs"   , 39));
		ndeck.push_back(CARD("2"    ,"Diamonds", 40));
		ndeck.push_back(CARD("3"    ,"Diamonds", 41));
		ndeck.push_back(CARD("4"    ,"Diamonds", 42));
		ndeck.push_back(CARD("5"    ,"Diamonds", 43));
		ndeck.push_back(CARD("6"    ,"Diamonds", 44));
		ndeck.push_back(CARD("7"    ,"Diamonds", 45));
		ndeck.push_back(CARD("8"    ,"Diamonds", 46));
		ndeck.push_back(CARD("9"    ,"Diamonds", 47));
		ndeck.push_back(CARD("10"   ,"Diamonds", 48));
		ndeck.push_back(CARD("Jack" ,"Diamonds", 49));
		ndeck.push_back(CARD("Queen","Diamonds", 50));
		ndeck.push_back(CARD("King" ,"Diamonds", 51));
		ndeck.push_back(CARD("Ace"  ,"Diamonds", 52));	
	}
	

	std::random_shuffle (ndeck.begin(),ndeck.end());
	return ndeck;
}

//---------------------------------------------------------------------
  static std::vector<CARD> deck;
  static int wallet = 500;
//----------------------------------------------------------------------
class hand
{
public:
   hand () 
   { }
   std::vector<CARD> cards;  // this is just an example
};

//----------------------------------------------------------------------
class player
{
 public:
  std::string name;
  hand Hand;
  int hand_value = 0;
  bool stand;
  bool win;
  bool has_ace;
  int bet = 0;
  int card_idx = 0;
  player() 
  {
     //std::cout << "Creating a new player " << std::endl;
  }
  virtual ~player() {}
  virtual void deliver(const chat_message& msg) = 0;
};

typedef std::shared_ptr<player> player_ptr;

//----------------------------------------------------------------------

class dealer
{
public:
  dealer() 
  {
     //std::cout << "Creating a dealer" << std::endl;
     deck = shuffle();
     current_player = NULL;
     card_idx=0;
  }
  void deal()
  {
  	  //add card class, and add random, and shuffle
  	CARD temp = hit();
  	hand_value += temp.get_numeric_value();
      	Hand.cards.push_back( temp );
	card_idx++;
	  
	if (temp.get_value().compare("Ace") == 0 && has_ace && hand_value > 21)
        {
      	  has_ace = true;
      	  hand_value -= 10;
        }
      			//Not sure about this. needs testing
      else if (temp.get_value().compare("Ace") == 0)
      {
      	has_ace = true;
      }
      			
      if (has_ace && hand_value > 21)
      {
      	hand_value -= 10;
      	has_ace = false;
      }

      temp = hit();
      hand_value += temp.get_numeric_value();
      Hand.cards.push_back( temp );
      card_idx++;
      
      if (temp.get_value().compare("Ace") == 0 && has_ace && hand_value > 21)
      {
      	has_ace = true;
      	hand_value -= 10;
      }
      			//Not sure about this. needs testing
      else if (temp.get_value().compare("Ace") == 0)
      {
      	has_ace = true;
      }
      			
      if (has_ace && hand_value > 21)
      {
      	hand_value -= 10;
      	has_ace = false;
      }
     
     for (auto player_: players)
     {
       
      //std::cout<<player_->name<< " is being dealt\n";
      temp = hit();
      player_->hand_value+=temp.get_numeric_value();
      player_->Hand.cards.push_back( temp );
      player_->card_idx++;
      
      if (temp.get_value().compare("Ace") == 0 && player_->has_ace && player_->hand_value > 21)
      {
      	player_->has_ace = true;
      	player_->hand_value -= 10;
      }
      			//Not sure about this. needs testing
      else if (temp.get_value().compare("Ace") == 0)
      {
      	player_->has_ace = true;
      }
      			
      if (player_->has_ace && player_->hand_value > 21)
      {
      	player_->hand_value -= 10;
      	player_->has_ace = false;
      }
      
      temp = hit();
      player_->hand_value+=temp.get_numeric_value();
      player_->Hand.cards.push_back( temp );
      player_->card_idx++;
      
      if (temp.get_value().compare("Ace") == 0 && player_->has_ace && player_->hand_value > 21)
      {
      	player_->has_ace = true;
      	player_->hand_value -= 10;
      }
      			//Not sure about this. needs testing
      else if (temp.get_value().compare("Ace") == 0)
      {
      	player_->has_ace = true;
      }
      			
      if (player_->has_ace && player_->hand_value > 21)
      {
      	player_->hand_value -= 10;
      	player_->has_ace = false;
      }
 //std::cout<<(player_->name);
     }
 
  }
  
  CARD hit()
  {
    CARD next((deck.front()).get_value(),(deck.front()).get_suite(), (deck.front()).get_reference() );
    //std::cout<<"The card being drawn is a "<<next.get_value()<<std::endl;
     
    //std::cout<<"The card being removed from deck is a "<<deck.front().get_value()<<std::endl;
    deck.erase(deck.begin());
    

    return next;
  }

  void next_player ( player_ptr p )
  {
     current_player = p;
  }

  
  player_ptr current_player;
  hand Hand;
  bool has_ace;
  int hand_value;
  int card_idx;
  //we need the dealer to have an array of players in scope
  std::set<player_ptr> players;
};

class blackjack_table
{
public:
  void join(player_ptr player_)
  {
    //std::cout << "joining the table" << std::endl;
    players.insert(player_);
    Dealer.players = players;
    //for (auto msg: recent_msgs_)
    //  player_->deliver(msg);
  }

  void leave(player_ptr player_)
  {
    //std::cout << "leaving the table" << std::endl;
    players.erase(player_);
  }

  void deliver(const chat_message& msg)
  {
    recent_msgs_.push_back(msg);
    while (recent_msgs_.size() > max_recent_msgs)
      recent_msgs_.pop_front();

    for (auto player_: players)
      player_->deliver(msg);
  }
  
	//change to all players have bet
  bool all_players_have_bet()
  {

     for (auto player_: players)
     {
       //std::cout<<(player_->name);
       if(player_->bet == 0)
       {
       		return false;
       }
     }
     return true;
  }
  
  bool all_players_stand()
  {
  	for (auto player_: players)
  	{
  		if(!player_->stand )
  		{
  			return false;
  		}
  	}
  	return true;
  }

  dealer Dealer;
  bool game_started = false;
private:
  std::set<player_ptr> players;
  enum { max_recent_msgs = 1 };
  chat_message_queue recent_msgs_;
};

//----------------------------------------------------------------------
//TODO create wincheck, hit (actual), split, double
//
//
//

class blackjack_player
  : public player,
    public std::enable_shared_from_this<blackjack_player>
{
public:
  blackjack_player(tcp::socket socket, blackjack_table& table)
    : socket_(std::move(socket)),
      table_(table)
  {
     //std::cout << "Creating a blackjack_player " << std::endl;
  }

  void start()
  {
    table_.join(shared_from_this());
    do_read_header();
  }

  void deliver(const chat_message& msg)
  {
    bool write_in_progress = !write_msgs_.empty();
    write_msgs_.push_back(msg);
    if (!write_in_progress)
    {
      do_write();
    }
  }

private:
  void do_read_header()
  {
    auto self(shared_from_this());
    asio::async_read(socket_,
        asio::buffer(read_msg_.data(), chat_message::header_length),
        [this, self](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec && read_msg_.decode_header())
          {
            do_read_body();
          }
          else
          {
            table_.leave(shared_from_this());
          }
        });
  }

  void do_read_body()
  {
  //
  //hit,double, all_players_stand(this is where the dealer draws), then win check,split
  //
  
    auto self(shared_from_this());
    asio::async_read(socket_,
        asio::buffer(read_msg_.body(), read_msg_.body_length()),
        [this, self](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec)
          {
            // Here is where messages arrive from the client
            // this is where the design makes it easy or hard

            // ignore anything in the message body
            read_msg_.body_length(0);
            read_msg_.gs.dealer_cards_valid = false;
            read_msg_.gs.player_cards_valid = false;

            // is it a join
            if (read_msg_.ca.join /*&& read_msg_.ca.name_valid*/)
            {
               //while(table_.game_started)
               //{}
               //std::cout << "the name is " << read_msg_.ca.name << std::endl;
               std::string m = std::string(read_msg_.ca.name) + " has joined.";     
               strcpy(read_msg_.body(),m.c_str());
               read_msg_.body_length(strlen(read_msg_.body()));
               self->name = std::string (read_msg_.ca.name);
               
            }
            
            //if bet?
            if (self->name > "") // quick way to see if they have entered a name
            {
                if (read_msg_.ca.hit && table_.game_started) // also need to check in order, since everyone has a turn
                {
                   // call the dealer class with some kind of method and
                   // argument
                   std::string m = self->name + " has asked for a hit.";

                strcpy(read_msg_.body(),m.c_str());
                read_msg_.body_length(strlen(read_msg_.body()));
                	
                CARD temp = table_.Dealer.hit();
      			self->hand_value+=temp.get_numeric_value();
      			self->Hand.cards.push_back( temp );
      			self->card_idx++;
      			
      			if (temp.get_value().compare("Ace") == 0 && self->has_ace && self->hand_value > 21)
      			{
      				self->has_ace = true;
      				self->hand_value -= 10;
      			}
      			//Not sure about this. needs testing
      			else if (temp.get_value().compare("Ace") == 0)
      			{
      				self->has_ace = true;
      			}
      			
      			if (self->has_ace && self->hand_value > 21)
      			{
      				self->hand_value -= 10;
      				self->has_ace = false;
      			}
      			
      			read_msg_.gs.game_started = true;	
				read_msg_.gs.dealer_cards_valid = true;
               	read_msg_.gs.player_cards_valid = true;
               	
                read_msg_.ca.join = false;
                
               	read_msg_.gs.dealer_cards[0] = table_.Dealer.Hand.cards[0].reference;
               	read_msg_.gs.dealer_cards[1] = table_.Dealer.Hand.cards[1].reference;
            
               	int i = 0;
               	for (auto player_: table_.Dealer.players)
               	{
               		
               		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
					for (int j = 0; j < player_->card_idx; j++)
					{
						read_msg_.gs.player_cards[i][j] = player_->Hand.cards[j].reference;
               		}
               		i++;
      			//std::cout<<(player_->name);
     				}
                   // also set read_msg.gs.XXX to whatever needs to go to the clients
                }
                
                else if(read_msg_.ca.bet && !table_.game_started )
                {
	                self->bet = read_msg_.ca.bet_val;
	                //std::cout<<self->name << " is betting "<< self->bet<<std::endl;
                }
                
                else if ( read_msg_.ca.double_hit && table_.game_started)
                {
                	//std::cout<<"test\n";
                	self->bet *= 2;
                	
                std::string m = self->name + " has doubled down.";
                strcpy(read_msg_.body(),m.c_str());
                read_msg_.body_length(strlen(read_msg_.body()));
                	
                CARD temp = table_.Dealer.hit();
      			self->hand_value+=temp.get_numeric_value();
      			self->Hand.cards.push_back( temp );
      			self->card_idx++;
      			
      			if (temp.get_value().compare("Ace") == 0 && self->has_ace && self->hand_value > 21)
      			{
      				self->has_ace = true;
      				self->hand_value -= 10;
      			}
      			//Not sure about this. needs testing
      			else if (temp.get_value().compare("Ace") == 0)
      			{
      				self->has_ace = true;
      			}
      			
      			if (self->has_ace && self->hand_value > 21)
      			{
      				self->hand_value -= 10;
      				self->has_ace = false;
      			}
      			
      			read_msg_.gs.game_started = true;	
				read_msg_.gs.dealer_cards_valid = true;
               	read_msg_.gs.player_cards_valid = true;
               	
                read_msg_.ca.join = false;
                
               	read_msg_.gs.dealer_cards[0] = table_.Dealer.Hand.cards[0].reference;
               	read_msg_.gs.dealer_cards[1] = table_.Dealer.Hand.cards[1].reference;
            
               	int i = 0;
               	for (auto player_: table_.Dealer.players)
               	{
               		
               		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
					for (int j = 0; j < player_->card_idx; j++)
					{
					read_msg_.gs.player_cards[i][j] = player_->Hand.cards[j].reference;
               		}
               		i++;
      			//std::cout<<(player_->name);
     			}
     			self->stand = true;
     		    }
     		    
     		    else if ( read_msg_.ca.stand && table_.game_started)
                {
                //logic for stand
                std::string m = self->name + " is staying.";
                strcpy(read_msg_.body(),m.c_str());
                read_msg_.body_length(strlen(read_msg_.body()));
      			
      			read_msg_.gs.game_started = true;	
				read_msg_.gs.dealer_cards_valid = true;
               	read_msg_.gs.player_cards_valid = true;
               	
                read_msg_.ca.join = false;
                
               	read_msg_.gs.dealer_cards[0] = table_.Dealer.Hand.cards[0].reference;
               	read_msg_.gs.dealer_cards[1] = table_.Dealer.Hand.cards[1].reference;
            
               	int i = 0;
               	for (auto player_: table_.Dealer.players)
               	{
               		
               		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
					for (int j = 0; j < player_->card_idx; j++)
					{
					read_msg_.gs.player_cards[i][j] = player_->Hand.cards[j].reference;
               		}
               		i++;
      			//std::cout<<(player_->name);
     			}
     			self->stand = true;

                }
            }

            // display the cards if eveFryone has joinedf
            //if all players have bet
            if (table_.all_players_have_bet() && !table_.game_started && table_.Dealer.current_player==NULL)
            {
			   sleep(1);
			   read_msg_.gs.game_started = true;
			   table_.game_started = true;
			   
               table_.Dealer.deal();
               
               read_msg_.gs.dealer_cards_valid = true;
               read_msg_.gs.player_cards_valid = true;
              
               read_msg_.gs.dealer_cards[0] = table_.Dealer.Hand.cards[0].reference;
               read_msg_.gs.dealer_cards[1] = table_.Dealer.Hand.cards[1].reference;
            
               int i = 0;
               for (auto player_: table_.Dealer.players)
               {
               		CARD temp;
               		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
               		//std::cout<<(player_->name)<< " "<<read_msg_.gs.playernames[i]<<std::endl;
     				//std::cout<<player_->name<< " is being handed cards\n";
					read_msg_.gs.player_cards[i][0] = player_->Hand.cards[0].reference;
               		read_msg_.gs.player_cards[i][1] = player_->Hand.cards[1].reference;
					read_msg_.gs.player_cards[i][2] = 0;
               		read_msg_.gs.player_cards[i][3] = 0;
					read_msg_.gs.player_cards[i][4] = 0;
               		read_msg_.gs.player_cards[i][5] = 0;
               		i++;
      			//std::cout<<(player_->name);
     			}
     			
     		//std::cout<< " Test\n";
             	
            }
           

            //construct player in gs
            read_msg_.encode_header(); // so the body text above gets sent
            table_.deliver(read_msg_);
            do_read_header();
            
          if(table_.game_started)
          //initial cards have been handed out, now we add logic to talk to each player specifically
          //current_player
          {
          for (auto player_: table_.Dealer.players)
          {
			if(!player_->stand && player_-> hand_value < 22)
			{
				int i = 0;
				for (auto player_: table_.Dealer.players)
               	{
               		
               		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
					for (int j = 0; j < player_->card_idx; j++)
					{
					read_msg_.gs.player_cards[i][j] = player_->Hand.cards[j].reference;
               		}
               		i++;
      			//std::cout<<(player_->name);
     			}
				
				read_msg_.ca.myturn = true;
          		table_.Dealer.current_player = player_;
            	std::string da = "";
            	if(player_->card_idx == 2)
            	{
            	   da = player_->name + ", your hand value is currently " + std::to_string(player_->hand_value) +
            	   ". Do you want to hit, double, or stay?";  
            	}
            	else
            	{   
               		da = player_->name + ", your hand value is currently " + std::to_string(player_->hand_value) +
               		". Do you want to hit or stay?";  
				}
				   
            	strcpy(read_msg_.body(),da.c_str());
            	read_msg_.body_length(strlen(read_msg_.body()));
            	//std::cout<<da<<std::endl;
               
            	read_msg_.encode_header(); // so the body text above gets sent
            	player_->deliver(read_msg_);
            	
            	
            }
            else if(player_->hand_value > 21) // to tell the player he busted
            {
            	std::string bst = "You busted!";
            	strcpy(read_msg_.body(),bst.c_str());
            	read_msg_.body_length(strlen(read_msg_.body()));
            	//std::cout<<bst<<std::endl;
               
            	read_msg_.encode_header(); // so the body text above gets sent
            	player_->deliver(read_msg_);
            	player_->stand = true;
            	
            }
            else if(player_->stand) // to tell the player he busted
            {
            	std::string bst = "You're standing.";
            	strcpy(read_msg_.body(),bst.c_str());
            	read_msg_.body_length(strlen(read_msg_.body()));
            	//std::cout<<bst<<std::endl;
               
            	read_msg_.encode_header(); // so the body text above gets sent
            	player_->deliver(read_msg_);
            	player_->stand = true;
            	
            	//std::cout<<"testing for send stuff"<<std::endl;
            }
           }
            if (table_.all_players_stand())
            {
				read_msg_.gs.dealers_turn = true;
				
				read_msg_.encode_header();
				table_.deliver(read_msg_);
				
            	//std::cout << "here is where we add dealer checks\n";
            	//adding dealer hit then sleep cycle until dealer hand > 17
            	std::cout << table_.Dealer.hand_value<<std::endl; 
            	while ((table_.Dealer.hand_value < 17) || (table_.Dealer.has_ace && table_.Dealer.hand_value ==17))
 	           	{
    	        	sleep(1); 
    	        	
    	        	CARD temp = table_.Dealer.hit();
  	  		table_.Dealer.hand_value += temp.get_numeric_value();
     	 		table_.Dealer.Hand.cards.push_back( temp );
	 		table_.Dealer.card_idx++;
	 				
					if (temp.get_value().compare("Ace") == 0 && table_.Dealer.has_ace && table_.Dealer.hand_value > 21)
      				{
      					table_.Dealer.has_ace = true;
      					table_.Dealer.hand_value -= 10;
      				}
      			//Not sure about this. needs testing
      				else if (temp.get_value().compare("Ace") == 0)
      				{
      					table_.Dealer.has_ace = true;
      				}
      			
     				if (table_.Dealer.has_ace && table_.Dealer.hand_value > 21)
      				{
      					table_.Dealer.hand_value -= 10;
      					table_.Dealer.has_ace = false;
      				}	
      				
      				read_msg_.gs.game_started = true;	
				read_msg_.gs.dealer_cards_valid = true;
    	           		read_msg_.gs.player_cards_valid = true;
               	
    	            read_msg_.ca.join = false;
                	
                	for (int i = 0; i<table_.Dealer.card_idx; i++)
                	{
    	           		read_msg_.gs.dealer_cards[i] = table_.Dealer.Hand.cards[i].reference;
    	           	}
    	           	
    	           	int i = 0;
    	           	for (auto player_: table_.Dealer.players)
    	           	{
               		
    	           		strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
						for (int j = 0; j < player_->card_idx; j++)
						{
							read_msg_.gs.player_cards[i][j] = player_->Hand.cards[j].reference;
    	           		}
    	           		i++;
      			//std::cout<<(player_->name);
     				}
                   // also set read_msg.gs.XXX to whatever needs to go to the clients
                	read_msg_.encode_header(); // so the body text above gets sent
            		table_.deliver(read_msg_);
            	}
            	//
            	
            	//win_check
            	
            	for (auto player_: table_.Dealer.players)
               	{
               		if(player_->hand_value == 21 && player_->card_idx ==2)
               		{
               		read_msg_.gs.player_won = false;
               	  	read_msg_.gs.blackjack = true;
               	  	read_msg_.gs.push = false;
               	  	//player busted
               	  	wallet-=(player_->bet)*1.5;
               		std::string bst = "BLACKJACK!!";
            		strcpy(read_msg_.body(),bst.c_str());
            		read_msg_.body_length(strlen(read_msg_.body()));
            		//std::cout<<bst<<std::endl;
               
            		read_msg_.encode_header(); // so the body text above gets sent
            		player_->deliver(read_msg_);
            		
               		}
               	  
               	  else if ( player_->hand_value > 21 )
               	  {
               	  	read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
               	  	wallet+=player_->bet;
               		std::string bst = "You lost!";
            		strcpy(read_msg_.body(),bst.c_str());
            		read_msg_.body_length(strlen(read_msg_.body()));
            		//std::cout<<bst<<std::endl;
               
            		read_msg_.encode_header(); // so the body text above gets sent
            		player_->deliver(read_msg_);
            		read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
            		
               	  }
               	  else if( table_.Dealer.hand_value > 21)
               	  {
               	  		//dealer busted and player didnt
               	  	read_msg_.gs.player_won = true;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
               	  	wallet-=player_->bet;
               		std::string bst = "You won";
            		strcpy(read_msg_.body(),bst.c_str());
            		read_msg_.body_length(strlen(read_msg_.body()));
            		//std::cout<<bst<<std::endl;
               
            		read_msg_.encode_header(); // so the body text above gets sent
            		player_->deliver(read_msg_);
            		read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
               	  }
               	  
               	  else if (table_.Dealer.hand_value < player_->hand_value)
               	  {
               	  	//players hand is better than dealers hand
               	  	read_msg_.gs.player_won = true;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
               	  	wallet+=player_->bet;
               		std::string bst = "You won!";
            		strcpy(read_msg_.body(),bst.c_str());
            		read_msg_.body_length(strlen(read_msg_.body()));
            		//std::cout<<bst<<std::endl;
               
            		read_msg_.encode_header(); // so the body text above gets sent
            		player_->deliver(read_msg_);
            		read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
               	  }
               	  else if (table_.Dealer.hand_value == player_->hand_value)
               	  {
               	  	//push
               	  	read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = true;
               	  	read_msg_.gs.blackjack = false;
               	  	wallet+=player_->bet;
               		std::string bst = "Push!";
            		strcpy(read_msg_.body(),bst.c_str());
            		read_msg_.body_length(strlen(read_msg_.body()));
            		read_msg_.gs.player_won = false;
               	  	read_msg_.gs.push = false;
               	  	read_msg_.gs.blackjack = false;
            		//std::cout<<bst<<std::endl;
               	  }		
               	  else
               	  {
               	  		//players hand is less than dealers
               	  }
				  player_-> bet = 0;
  				  player_-> card_idx = 0;
      			
     			}
            	
            	//reseting game state
            	int i=0;

            	for (auto player_: table_.Dealer.players)
               	{
               	  strcpy(read_msg_.gs.playernames[i], (player_->name).c_str());
               	  //removes all player cards
		  for (int j = 0; j < (int)player_->Hand.cards.size(); j++)
		  {
		  	player_->Hand.cards.clear();
               	  }
               	  
                  i++;
				  player_-> hand_value = 0;
				  player_-> stand = false;
				  player_-> has_ace = false;
				  player_-> win = false;
				  player_-> bet = 0;
  				  player_-> card_idx = 0;
      			
     			}
     			
     		for (int j = 0; j < (int) table_.Dealer.Hand.cards.size(); j++)
		{
			table_.Dealer.Hand.cards.clear();
               	}
     			
            	  read_msg_.ca.bet = false;
            	  read_msg_.gs.game_started = false;
            	  read_msg_.ca.myturn = false;
            	  read_msg_.gs.player_won = false;
              	  read_msg_.gs.push = false;
               	  read_msg_.gs.blackjack = false;
                  read_msg_.gs.dealer_cards_valid = 0;
                  table_.Dealer.card_idx = 0;
                  table_.Dealer.hand_value = 0;
                  for(int j = 0; j< 6; j++)
                  {
                  	read_msg_.gs.dealer_cards[j] = 0;
                  }
   		 read_msg_.gs.player_cards_valid = false;
                   
                   for (i = 0; i<6;i++)
                   {
                   		for(int j = 0; j< 6; j++)
                   		{
                   			read_msg_.gs.player_cards[i][j] = 0;
                   		}
                   }
                   
            	table_.Dealer.current_player = NULL;
            	table_.game_started = false;	
            	deck = shuffle();  
            	                 
                read_msg_.encode_header(); // so the body text above gets sent
            	table_.deliver(read_msg_);
            	do_read_header();
            	
            }
            
            
          
          }
        }
        else
        {
          table_.leave(shared_from_this());
        }
       });
  }

  void do_write()
  {
    auto self(shared_from_this());
    asio::async_write(socket_,
        asio::buffer(write_msgs_.front().data(),
          write_msgs_.front().length()),
        [this, self](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec)
          {
            write_msgs_.pop_front();
            if (!write_msgs_.empty())
            {
              do_write();
            }
          }
          else
          {
            table_.leave(shared_from_this());
          }
        });
  }
  tcp::socket socket_;
  blackjack_table& table_;
  chat_message read_msg_;
  chat_message_queue write_msgs_;
};

//----------------------------------------------------------------------
class blackjack_game
{
public:
  blackjack_game(asio::io_context& io_context,
      const tcp::endpoint& endpoint)
    : acceptor_(io_context, endpoint)
  {
    //std::cout << "Creating a blackjack_game" << std::endl;
    do_accept();
  }

private:
  void do_accept()
  {
    acceptor_.async_accept(
        [this](std::error_code ec, tcp::socket socket)
        {
          if (!ec)
          {
            std::make_shared<blackjack_player>(std::move(socket), table_)->start();
          }

          do_accept();
        });
  }

  tcp::acceptor acceptor_;
  blackjack_table table_;
};

//----------------------------------------------------------------------

int main(int argc, char* argv[])
{


  try
  {
    if (argc < 2)
    {
      std::cerr << "Usage: blackjack_game <port> [<port> ...]\n";
      return 1;
    }

    asio::io_context io_context;

    std::list<blackjack_game> servers;
    for (int i = 1; i < argc; ++i)
    {
      tcp::endpoint endpoint(tcp::v4(), std::atoi(argv[i]));
      servers.emplace_back(io_context, endpoint);
    }

    io_context.run();
  }
  catch (std::exception& e)
  {
    std::cerr << "Exception: " << e.what() << "\n";
  }

  return 0;
}
