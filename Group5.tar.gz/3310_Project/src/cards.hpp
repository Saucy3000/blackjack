#ifndef CARDS_HPP
#define CARDS_HPP

#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>


class cards
{
	
};

class hand
{
	std::vector<cards> hand;
};

class test
{
   
};

struct FromPlayer
{

};

struct FromDealer
{
  std::string test;

  size_t length const = sizeof(struct FromDealer);
 

};

#endif
