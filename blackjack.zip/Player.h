#ifndef PLAYER_H
#define PLAYER_H
#include "Cards.h"

using namespace std;

class PLAYER
{
	public:
		PLAYER();
		PLAYER(string n, vector<CARD> h, int b, bool g);
		int balance;
		vector<CARD> hand;
		bool game_over;
		string name;
		
	protected:
		
		
};

#endif
