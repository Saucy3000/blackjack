#include "Player.h"

PLAYER::PLAYER() // Defualt Constructor
{
	name = "JERRY";
	balance=100;
	game_over = false;
	
}

PLAYER::PLAYER(string n, vector<CARD> h, int b, bool g)
{
	name=n;
	hand=h;
	balance=b;
	game_over= g;
}

