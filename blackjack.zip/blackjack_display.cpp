#include <iostream>
#include <iomanip>
#include <unistd.h> 
#include <ctime>
#include "Dealer.h"
#include "Player.h"




using namespace std;

void get_help()
{
	string help = R"(
HELP___________________________________________________________
                                                               |
The goal of blackjack is to get a total of 21 for your cards.  |
If you go over 21 you automatically bust.Each numbered card is | 
worth th value on the card. Face cardsare worth 10 and aces    |
are worth 1 or 11 (you get to choose).                         |
                                                               |
The dealer will deal every player and himself 2 cards to start | 
the game. Each player takes his turn trying to beat the dealer |
to closesest to 21. You will get the following options:        |
HIT    - You get one more card and continue your turn.         |
STAY   - You end your turn and keep the card amount you have.  |
DOUBLE - You double your bet amount, get exactly one morecard, | 
         and you end your turn.                                |
                                                               |
*If at anytime you go over 21 you bust and your turn is        | 
 automatically ended.                                          |
*You win automatically if the dealer bust and you have not.    |
*You win automatically if you start with 21.                   |
*If you and the dealer have the same amount you push(do not    | 
 lose or win any money).                                       |
_______________________________________________________________|
)";
	
	std::cout << help;
}

int get_bet(PLAYER p)
{
	int Bet;
	cout <<  "How much would you like to bet " << p.name << "?" << endl;
	cout << "1-$1 | 2-$2 | 3-$3 | 4-$4 | 5-$5" << endl;
	cin >> Bet;
	cin.ignore();
	if (Bet != 1 && Bet != 2 && Bet != 3 && Bet != 4 && Bet != 5)
	{
		cout << "Please enter in one of the selected amounts" << endl;
		get_bet(p);
	}
	if (Bet > p.balance)
	{
		cout << "insuficent funds. please select a lesser amount" << endl;
		get_bet(p);
	}
	
	return Bet;
	
}

int main ()
{
	srand(time(NULL));
	string fname;
	int CurrentBet;
	DEALER dealer;
	CARD C;
	vector<CARD> deck;
	vector<CARD> empty;
	
	
	cout << "Welcome to CASINO ROYALE!\n\nThe starting amount is $100\n" << "Please enter your first name: ";
	cin >> fname;
	cin.ignore();
	PLAYER p1;
	p1.name = fname;
	cout << "welcome " << p1.name << endl;
	usleep(1100000);
	get_help();
	cout << "Press Enter to continue";
	cin.ignore();
	
	deck= C.shuffle();
	std::random_shuffle (deck.begin(),deck.end());
	CurrentBet =get_bet(p1);
	p1.balance -= CurrentBet;
	
	cout << p1.name << " balance: $" << p1.balance << endl;
	
	/*for (auto j : deck)
	{
		cout << left << setw(5) << j.value << " " <<j.suite << endl;
	}*/
	
	
	cout << "boom" << endl;
	
	
	



 return 0;
}
