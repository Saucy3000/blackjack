#include "Dealer.h"

DEALER::DEALER() // Defualt Constructor
{
	balance=500;
}

DEALER::DEALER(vector<CARD> h, int b)
{
	hand=h;
	balance=b;
}

//int DEALER::DEALER get_balance()
//{
//	return balance;
//}
