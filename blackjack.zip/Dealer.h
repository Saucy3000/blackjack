#ifndef DEALER_H
#define DEALER_H
#include "Cards.h"

using namespace std;

class DEALER
{
	public:
		DEALER();
		DEALER(vector<CARD> h, int b);
		int get_balance();
		vector<CARD> hand;
		
	protected:
		
		int balance;
};

#endif
