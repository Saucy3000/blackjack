#ifndef CARDS_H
#define CARDS_H
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>


class CARD
{
	public:
		CARD();
		CARD(std::string v, std::string s, int ref);
		int get_numeric_value();
		void set_value(std::string s);
		void set_suite(std::string s);
		std::string get_value();
		std::string get_suite();
		int get_reference();
		//vector<CARD> shuffle();

		std::string value;
		std::string suite;
		int reference;
		//string to_string() const;
	protected:
};


class DECK
{
  public:
   	std::vector<CARD> deck;
   	DECK();
    
    CARD ref_check(int ref);

};
#endif
