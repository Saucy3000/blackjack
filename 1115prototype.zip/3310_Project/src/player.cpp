// CSE3310 Fall 2019


#include <iostream>
#include <cstdlib>
#include <deque>
#include <iostream>
#include <thread>
#include <assert.h>
#include<vector>
#include<unistd.h>
#include<string>
#include "asio.hpp"
#include "chat_message.hpp"
#include "cards.cpp"

//GtkWidget *fromView  = NULL;  // text from the chat server
//GtkWidget *dealerCards = NULL;
//GtkWidget *playerCards = NULL;

using asio::ip::tcp;

typedef std::deque<chat_message> chat_message_queue;
// global symbols
char name[25];


static void intakeBet();

class hand
{
public:
   hand () 
   { }
   std::vector<CARD> cards;  // unique to local player
};

class chat_client
{
public:
  char player[25];
  hand Hand;
  DECK ref_deck;

  chat_client(asio::io_context& io_context,
      const tcp::resolver::results_type& endpoints)
    : io_context_(io_context),
      socket_(io_context)
  {
    do_connect(endpoints);
  }

  void write(const chat_message& msg)
  {
    asio::post(io_context_,
        [this, msg]()
        {
          bool write_in_progress = !write_msgs_.empty();
          write_msgs_.push_back(msg);
          if (!write_in_progress)
          {
            do_write();
          }
        });
  }

  void close()
  {
    asio::post(io_context_, [this]() { socket_.close(); });
  }

private:
  void do_connect(const tcp::resolver::results_type& endpoints)
  {
    asio::async_connect(socket_, endpoints,
        [this](std::error_code ec, tcp::endpoint)
        {
          if (!ec)
          {
            do_read_header();
          }
        });
  }

  void do_read_header()
  {
    asio::async_read(socket_,
        asio::buffer(read_msg_.data(), chat_message::header_length),
        [this](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec && read_msg_.decode_header())
          {
            do_read_body();
          }
          else
          {
            socket_.close();
          }
        });
  }

  void do_read_body()
  {
    asio::async_read(socket_,
        asio::buffer(read_msg_.body(), read_msg_.body_length()),
        [this](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec)
          {
            if(read_msg_.gs.player_cards_valid)
            {
            	std::cout<<"Test success"<<std::endl;
            }
             
             
			 strcpy(player, name);
			   
			    if (strcmp(read_msg_.ca.name, name) == 0 && read_msg_.ca.join)
                {
            		intakeBet();
                } 
             

			 	std::string str(player);
             	char outline[read_msg_.body_length() + 2];
                                       // '\n' + '\0' is 2 more chars
             	outline[0] = '\n';
             	outline[read_msg_.body_length() + 1] = '\0';
             	std::memcpy ( &outline[1], read_msg_.body(), read_msg_.body_length() );
             	std::cout<<outline<<std::endl;

    /*           std::string p = "player "+ std::to_string (read_msg_.gs.player_cards[0][0]) + " " +
                                         std::to_string (read_msg_.gs.player_cards[0][1]) + " " +
                                         std::to_string (read_msg_.gs.player_cards[0][2]) + '\n' +
                                         std::to_string (read_msg_.gs.player_cards[1][0]) + " " +
                                         std::to_string (read_msg_.gs.player_cards[1][1]) + " " +
                                         std::to_string (read_msg_.gs.player_cards[1][2]);
    */
    			
    			if (read_msg_.gs.game_started)
    			{         	
             	  for(int i = 0; i < 6; i++)
             	  {
             		if (strlen(read_msg_.gs.playernames[i]) == 0)
             		{
             			break;
             		}
             		std::cout<<"Player "<< i << " is "<<read_msg_.gs.playernames[i]<<std::endl;
             	  }
             	}
             	
             	
             	std::string p = str + "'s hand: \n\t" + (ref_deck.ref_check(read_msg_.gs.player_cards[0][0])).get_value() + " of " +  (ref_deck.ref_check(read_msg_.gs.player_cards[0][0])).get_suite() + "\n\t"
               + (ref_deck.ref_check(read_msg_.gs.player_cards[0][1])).get_value() + " of " +  (ref_deck.ref_check(read_msg_.gs.player_cards[0][1])).get_suite();
 
 
 				
               
               //on dealer play it'll reveal facedown card and draw if it needs to
               	std::string d = "dealer up card:  " +  (ref_deck.ref_check(read_msg_.gs.dealer_cards[0])).get_value() + " of " +  (ref_deck.ref_check(read_msg_.gs.dealer_cards[0])).get_suite();
                                                      /*read_msg_.gs.dealer_cards[1])*/

				
               	if (read_msg_.gs.player_cards_valid)
               	{
                   std::cout<<p.c_str()<<std::endl;
                }
               	else
                   std::cout<<"Waiting for turn"<<std::endl;

               	if (read_msg_.gs.dealer_cards_valid)
               	{
                  std::cout<<d.c_str()<<std::endl;
                }
               	else
                  std::cout<<"Waiting for dealer"<<std::endl;
            

      //      std::cout.write(read_msg_.body(), read_msg_.body_length());
      //      std::cout << "\n";
              do_read_header();
          	
          
          }
          else
          {
            socket_.close();
          }
        });
  }
  
  void do_write()
  {
    asio::async_write(socket_,
        asio::buffer(write_msgs_.front().data(),
          write_msgs_.front().length()),
        [this](std::error_code ec, std::size_t /*length*/)
        {
          if (!ec)
          {
            write_msgs_.pop_front();
            if (!write_msgs_.empty())
            {
              do_write();
            }
          }
          else
          {
            socket_.close();
          }
        });
  }

private:
  asio::io_context& io_context_;
  tcp::socket socket_;
  chat_message read_msg_;
  chat_message_queue write_msgs_;
};

// global symbols
chat_client *c;
int wallet = 100;

//do similar for double, stand, split
static void hitCallback()
{
   chat_message msg;
   msg.body_length (0);
   msg.ca.hit = true;
   msg.ca.stand = false;
   msg.ca.name_valid = false;
   
   msg.encode_header();
   assert ( c );  // this is a global class
   c->write(msg);
}

static void intakeBet()
{

	int Bet;
	std::cout <<  "How much would you like to bet, " << name << "?" << std::endl;
	std::cout << "1-$1 | 2-$2 | 3-$3 | 4-$4 | 5-$5" << std::endl;
	std::cin >> Bet;
	std::cin.ignore();
	
	if (Bet > wallet)
	{
		std::cout <<  "Out of Money, " << name << ". Good luck telling your family!" << std::endl;
		exit (1);
	}
	assert(Bet < 6 || Bet > 0);
	
	chat_message msg;

	if (strlen(name) < sizeof(msg.ca.name))
	{
		strcpy(msg.ca.name,name);
	}
	
   	msg.body_length (0);
   	msg.ca.hit = false;
   	msg.ca.stand = false;
   	msg.ca.name_valid = false;
   	msg.ca.join = false;
   	msg.ca.split = false;
   	msg.ca.double_hit = false;
   	msg.ca.bet = true;
   	msg.ca.bet_val = Bet;
    
	msg.encode_header();
	assert ( c ); // this is a global class
	c->write(msg);
}


static void joinplayer()
{
   std::cerr << "Player has started: " << std::endl;

  std::cout<<"Please enter your name: ";
  std::cin.getline(name, 26);


   if (name)
   {
      chat_message msg;
      msg.body_length (0);
      msg.ca.hit = false;
      msg.ca.stand = false;
      msg.ca.join = true;
      msg.ca.bet = false;
      msg.ca.name_valid = true;
      msg.ca.double_hit = false;
      msg.ca.split = false;
      

      //change this line to take a bet in its own function
      msg.ca.bet_val = 0;

      if (strlen(name) < sizeof(msg.ca.name))
      {
        strcpy(msg.ca.name,name);
      }

      msg.encode_header();
      assert ( c );  // this is a global class
      std::string str(name);
      c->write(msg);
   }

}

static void splitCallback()
{
   chat_message msg;
   msg.body_length (0);
   msg.ca.hit = false;
   msg.ca.stand = false;
   msg.ca.double_hit = false;
   msg.ca.name_valid = true;
   msg.ca.split =true;
   msg.encode_header();
   assert ( c );  // this is a global class
   c->write(msg);
}
static void standCallback()
{
   chat_message msg;
   msg.body_length (0);
   msg.ca.hit = false;
   msg.ca.stand = true;
   msg.ca.double_hit = false;
   msg.ca.name_valid = true;
   msg.ca.split =false;
   msg.encode_header();
   assert ( c );  // this is a global class
   c->write(msg);
}
static void doubleCallback()
{
   chat_message msg;
   msg.body_length (0);
   msg.ca.hit = false;
   msg.ca.stand = false;
   msg.ca.double_hit = true;
   msg.ca.name_valid = true;
   msg.ca.split =false;
   msg.encode_header();
   assert ( c );  // this is a global class
   c->write(msg);
}



int main(int argc, char *argv[])
{


//   hitButton = gtk_button_new_with_label("Hit");


   if (argc != 3)
   {
      std::cerr << "Usage: chat_client <host> <port>\n" ;
      return 1;
   }

   asio::io_context io_context;
   tcp::resolver resolver(io_context);
   auto endpoints = resolver.resolve(argv[1], argv[2]);
   c = new chat_client(io_context, endpoints);
   assert(c);

   std::thread t([&io_context](){ io_context.run(); });
   joinplayer();
   
   while(wallet > 0)
   {
   //enter actions for cards/hands
   //getline and switch for action?
   		//std::string input; 
   		//getline(std::cin, input);
   
   		//if(input.compare("hit") == 0)
   		//{
   			//hitCallback();
   		//	std::cout<<"test\n"<<std::endl;				 
   		//}
   }
   
   c->close();
   t.join();
   
   return 0;
}
